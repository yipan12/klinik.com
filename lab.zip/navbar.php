<nav class="pushmenu pushmenu-left">
         <h3><i class="glyphicon glyphicon-home"></i> Menu</h3>
 
        <li><a href="home.php?ref=home">Home</a>
 
        </li>
        <li><a href="home.php?ref=input_registrasi">Input Registrasi</a>
 
        </li>
        <li><a href="home.php?ref=daftar_kunjungan">Daftar Kunjungan</a>
 
        </li>
       	<li><a href="home.php?ref=hasil_uji">Hasil Uji</a>
 
        </li>
        
        <h3><i class="glyphicon glyphicon-tasks"></i> Data Dasar &amp; Pengaturan</h3>
 
        <li><a href="home.php?ref=kelompok_parameter_uji">Kelompok Parameter Uji</a>
 
        </li>
        <li><a href="home.php?ref=parameter_uji">Parameter Uji</a>
 
        </li>
		
        <li><a href="home.php?ref=paket_pemeriksaan">Paket Pemeriksaan</a>
 
        </li>
        
        <li><a href="home.php?ref=pekerjaan">Pekerjaan</a>
 
        </li>
		
        <li><a href="home.php?ref=jenis_pasien">Jenis Pasien</a>
 
        </li>
        <li><a href="home.php?ref=dokter">Dokter Pengirim</a>
 
        </li>
        
        <li><a href="home.php?ref=petugas">Petugas</a>
 
        </li>
		
        <li><a href="home.php?ref=pasien">Pasien</a>
 
        </li>
		
		<li><a href="home.php?ref=reagen">Reagen</a>
 
        </li>

		 <li><a href="home.php?ref=pengaturan">Pengaturan</a>
 
        </li>
        <li><a href="home.php?ref=log">Catatan Log</a>
 
        </li>
         <h3><i class="glyphicon glyphicon-file" ></i> Laporan</h3>
		
		<li><a href="home.php?ref=lap_reagen">Laporan Reagen</a>
 
        </li>
		
        <li><a href="home.php?ref=lap_rekap">Laporan Rekapitulasi</a>
 
        </li>
        <li><a href="home.php?ref=lap_bagi_hasil">Laporan Bagi Hasil</a>
		
		</li>
        <li><a href="home.php?ref=lap_10_besar">Laporan 10 Besar Parameter Uji</a>
		
		</li>
		
		 <h3><i class="glyphicon glyphicon-off"></i><a href="logout.php" style=" color:#FFF;"> Logout </a></h3>
 
    </nav>