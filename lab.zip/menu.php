<div id="menubar">
     <div id="cssmenu">
<ul>
   <li class='active'><a href='home.php' ><span>Home</span></a></li>
   <li class='has-sub'><a href='#'><span>Data &amp; pengaturan</span></a>
      <ul>
         <li><a href='#'><span>Kelompok Parameter Uji</span></a></li>
         <li><a href='#'><span>Parameter Uji</span></a></li>
         <li><a href='#'><span>Paket Pemeriksaan</span></a></li>
         <li><a href='#'><span>Pekerjaan</span></a></li>
         <li><a href='#'><span>Jenis Pasien</span></a></li>
         <li><a href='home.php?ref=dokter'><span>Dokter</span></a></li>
         <li><a href='home.php?ref=petugas'><span>Petugas</span></a></li>
         <li><a href='home.php?ref=pasien'><span>Pasien</span></a></li>
         <li><a href='#'><span>Pengaturan</span></a></li>
         <li><a href='#'><span>Catatan Log</span></a></li>
     </ul></li>
   <li class='has-sub'><a href='#'><span>Registrasi</span></a>
      <ul>
         <li><a href='home.php?ref=input_registrasi'><span>Input Registrasi</span></a></li>
         <li class='last'><a href='home.php?ref=daftar_kunjungan'><span>Daftar Kunjungan</span></a></li>
      </ul>
   </li>
   <li class='last'><a href='#'><span>Hasil uji</span></a></li>
<li class='has-sub'><a href='#'><span>Laporan</span></a>
      <ul>
         <li><a href='#'><span>Laporan Rekapitulasi</span></a></li>
         <li><a href='#'><span>Laporan Bagi Hasil</span></a></li>
         <li><a href='#'><span>Laporan 10 Besar Parameter Uji</span></a></li>
      </ul> </li>
      
      <li class='right'><a href='#'><span>Logout</span></a></li>
       </div>
      </div>
     