<div class="page-header">
    <div id="logo_image"></div>
                <div class="header"><p>Laboratorium Klinik</p>
			<h2>Betha Medika</h2>
		<p>Jl. Raya Jagawana, RT.4/4/RW.no 25, Sukarukun, Kec. Sukatani, Kabupaten Bekasi, Jawa Barat 17630</p>
        <p>No Telp 021 30123 666</p></div>
	</div>